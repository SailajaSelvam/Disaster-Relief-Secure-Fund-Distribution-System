# crypto_utils.py
import base64
import os
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding

# ----------- Symmetric key (AES-like using Fernet) -----------

def load_or_create_fernet_key(path: str = "fernet.key") -> Fernet:
    if os.path.exists(path):
        key = open(path, "rb").read()
    else:
        key = Fernet.generate_key()
        with open(path, "wb") as f:
            f.write(key)
    return Fernet(key)

# ----------- Asymmetric key pair for "digital signature" -----------

def load_or_create_rsa_keys(priv_path="rsa_private.pem", pub_path="rsa_public.pem"):
    if os.path.exists(priv_path) and os.path.exists(pub_path):
        with open(priv_path, "rb") as f:
            private_key = serialization.load_pem_private_key(f.read(), password=None)
        with open(pub_path, "rb") as f:
            public_key = serialization.load_pem_public_key(f.read())
    else:
        private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        public_key = private_key.public_key()
        with open(priv_path, "wb") as f:
            f.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption()
            ))
        with open(pub_path, "wb") as f:
            f.write(public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            ))
    return private_key, public_key


def encrypt_data(fernet: Fernet, plaintext: str) -> str:
    return fernet.encrypt(plaintext.encode()).decode()


def decrypt_data(fernet: Fernet, ciphertext: str) -> str:
    return fernet.decrypt(ciphertext.encode()).decode()

# ----------- Simple hash for “ZKP-style” proof (we only store hash) -----------

def hash_identity(victim_id: str, area_code: str) -> str:
    """Hash ID + area (used as fake ZKP proof)."""
    digest = hashes.Hash(hashes.SHA256())
    digest.update((victim_id + "|" + area_code).encode())
    return base64.b16encode(digest.finalize()).decode()

# ----------- Digital signature for fund transfer record -----------

def sign_transaction(private_key, message: str) -> str:
    signature = private_key.sign(
        message.encode(),
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32),
        hashes.SHA256()
    )
    return base64.b64encode(signature).decode()


def verify_signature(public_key, message: str, signature_b64: str) -> bool:
    try:
        signature = base64.b64decode(signature_b64.encode())
        public_key.verify(
            signature,
            message.encode(),
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32),
            hashes.SHA256()
        )
        return True
    except Exception:
        return False
