# db_utils.py
import sqlite3
from datetime import datetime
import hashlib
from pathlib import Path

DB_PATH = "disaster_fund.db"


def get_conn():
    Path(DB_PATH).touch(exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    cur = conn.cursor()

    # ---------- Victim table (includes email) ----------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS victims (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            did TEXT UNIQUE,
            name TEXT,
            phone TEXT,
            email TEXT,
            address TEXT,
            disaster_area TEXT,
            gov_id_hash TEXT UNIQUE,          -- ZKP-style hash proof
            encrypted_payload TEXT,    -- AES-encrypted JSON (includes bank details)
            status TEXT,               -- SUBMITTED / VERIFIED / REJECTED / FUNDED
            requested_amount REAL,
            approved_amount REAL,
            fund_status TEXT,          -- PENDING / APPROVED / TRANSFERRED
            created_at TEXT
        )
    """)

    # ---------- Users: Officer / Admin (includes email + region) ----------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            role TEXT,         -- OFFICER / ADMIN
            email TEXT,
            password TEXT,
            region TEXT        -- For OFFICER: which disaster_area they handle
        )
    """)

    # ---------- Blockchain simulation table ----------
    cur.execute("""
        CREATE TABLE IF NOT EXISTS blocks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            prev_hash TEXT,
            tx_data TEXT,
            tx_hash TEXT,
            signature TEXT,
            created_at TEXT
        )
    """)

    # ---------- Default demo accounts ----------
    cur.execute("SELECT COUNT(*) AS c FROM users")
    if cur.fetchone()["c"] == 0:
        # Officer for Chennai
        cur.execute(
            "INSERT INTO users(username, role, email, password, region) VALUES (?,?,?,?,?)",
            ("officer1", "OFFICER", "yyy@gmail.com", "officer123", "Chennai")
        )
        # Officer for Mumbai (extra example)
        cur.execute(
            "INSERT INTO users(username, role, email, password, region) VALUES (?,?,?,?,?)",
            ("officer2", "OFFICER", "zzzgmail.com", "officer234", "Mumbai")
        )
        # Admin (region = ALL)
        cur.execute(
            "INSERT INTO users(username, role, email, password, region) VALUES (?,?,?,?,?)",
            ("admin1", "ADMIN", "admin1@example.com", "admin123", "ALL")
        )

    conn.commit()
    conn.close()


# ---------------- Victim helpers ----------------

def insert_victim(did, name, phone, email, address, area, gov_id_hash,
                  encrypted_payload, requested_amount):

    conn = get_conn()
    conn.execute("""
        INSERT INTO victims
        (did, name, phone, email, address, disaster_area, gov_id_hash,
         encrypted_payload, status, requested_amount, approved_amount,
         fund_status, created_at)
        VALUES (?,?,?,?,?,?,?,?, 'SUBMITTED', ?, 0, 'PENDING', ?)
    """, (
        did, name, phone, email, address, area, gov_id_hash,
        encrypted_payload, requested_amount, datetime.utcnow().isoformat()
    ))

    conn.commit()
    conn.close()


def get_victims_by_status(status):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM victims WHERE status=?", (status,)
    ).fetchall()
    conn.close()
    return rows


def get_victims_by_status_and_region(status, region):
    """Used so officer sees only victims from their region."""
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM victims WHERE status=? AND disaster_area=?",
        (status, region)
    ).fetchall()
    conn.close()
    return rows


def update_victim_status(victim_id, status):
    conn = get_conn()
    conn.execute("UPDATE victims SET status=? WHERE id=?", (status, victim_id))
    conn.commit()
    conn.close()


def approve_fund(victim_id, amount):
    conn = get_conn()
    conn.execute("""
        UPDATE victims
        SET approved_amount=?, fund_status='APPROVED', status='VERIFIED'
        WHERE id=?
    """, (amount, victim_id))
    conn.commit()
    conn.close()


def mark_fund_transferred(victim_id):
    conn = get_conn()
    conn.execute("""
        UPDATE victims
        SET fund_status='TRANSFERRED', status='FUNDED'
        WHERE id=?
    """, (victim_id,))
    conn.commit()
    conn.close()


def get_victim_by_did(did):
    conn = get_conn()
    row = conn.execute(
        "SELECT * FROM victims WHERE did=?", (did,)
    ).fetchone()
    conn.close()
    return row


def get_victims_by_email(email):
    """Used for DID recovery via email."""
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM victims WHERE email=?", (email,)
    ).fetchall()
    conn.close()
    return rows


# ---------------- User helpers ----------------

def auth_user(username, password, role):
    """
    Return full user row if credentials match, else None.
    (Used for login + region-based access)
    """
    conn = get_conn()
    row = conn.execute(
        "SELECT * FROM users WHERE username=? AND password=? AND role=?",
        (username, password, role)
    ).fetchone()
    conn.close()
    return row  # Row object or None


def get_user(username, role=None):
    """Fetch user row by username (and optional role)."""
    conn = get_conn()
    if role:
        row = conn.execute(
            "SELECT * FROM users WHERE username=? AND role=?",
            (username, role)
        ).fetchone()
    else:
        row = conn.execute(
            "SELECT * FROM users WHERE username=?",
            (username,)
        ).fetchone()
    conn.close()
    return row


def get_user_email(username):
    conn = get_conn()
    row = conn.execute(
        "SELECT email FROM users WHERE username=?", (username,)
    ).fetchone()
    conn.close()
    return row["email"] if row else None

def get_user_row(username, role, password=None):
    """Return full user row (used for officer login with region)."""
    conn = get_conn()
    if password is None:
        row = conn.execute(
            "SELECT * FROM users WHERE username=? AND role=?",
            (username, role)
        ).fetchone()
    else:
        row = conn.execute(
            "SELECT * FROM users WHERE username=? AND password=? AND role=?",
            (username, password, role)
        ).fetchone()

    conn.close()
    return row



def update_user_password(username, new_password):
    conn = get_conn()
    conn.execute(
        "UPDATE users SET password=? WHERE username=?", (new_password, username)
    )
    conn.commit()
    conn.close()

def victim_exists_by_govid_hash(gov_hash):
    conn = get_conn()
    row = conn.execute("SELECT * FROM victims WHERE gov_id_hash=?", (gov_hash,)).fetchone()
    conn.close()
    return row is not None


# ---------------- Blockchain helpers ----------------

def _get_last_block_hash(conn):
    row = conn.execute(
        "SELECT tx_hash FROM blocks ORDER BY id DESC LIMIT 1"
    ).fetchone()
    return row["tx_hash"] if row else "0" * 64


def add_block(tx_data: str, signature: str):
    conn = get_conn()
    prev_hash = _get_last_block_hash(conn)
    h = hashlib.sha256((prev_hash + tx_data + signature).encode()).hexdigest()

    conn.execute("""
        INSERT INTO blocks(prev_hash, tx_data, tx_hash, signature, created_at)
        VALUES (?,?,?,?,?)
    """, (prev_hash, tx_data, h, signature, datetime.utcnow().isoformat()))

    conn.commit()
    conn.close()


def get_blocks():
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM blocks ORDER BY id"
    ).fetchall()
    conn.close()
    return rows
