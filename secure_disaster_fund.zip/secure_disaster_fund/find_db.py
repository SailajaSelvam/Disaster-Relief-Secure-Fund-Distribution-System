import os

search_name = "disaster_fund.db"
matches = []

for root, dirs, files in os.walk("D:\\", topdown=True):
    for file in files:
        if file == search_name:
            full = os.path.join(root, file)
            matches.append(full)
            print("FOUND:", full)

print("\nTotal matches:", len(matches))
