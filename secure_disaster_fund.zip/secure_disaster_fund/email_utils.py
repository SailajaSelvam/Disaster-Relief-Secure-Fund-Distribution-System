# email_utils.py
import smtplib
import random
from email.mime.text import MIMEText

# ----------------------------------------------------
# 🔧  CHANGE THESE VALUES FOR YOUR EMAIL ACCOUNT
# ----------------------------------------------------
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

SENDER_EMAIL = "xxx@gmail.com"          # <--- put your email here
SENDER_APP_PASSWORD = "put your password here " # <--- put your app password here

# You can change the subjects as you like (A/B/C/D)
SUBJECT_DID_RECOVERY = "A: DID Recovery Code"
SUBJECT_ADMIN_RESET  = "B: Admin Password Reset Code"
SUBJECT_OFFICER_RESET = "C: Officer Password Reset Code"
SUBJECT_GENERIC = "D: Verification Code"
# ----------------------------------------------------


def generate_otp() -> str:
    """Generate a 4-digit numeric code as string."""
    return f"{random.randint(1000, 9999)}"


def send_otp_email(to_email: str, subject: str, code: str):
    """
    Send the 4-digit OTP to the given email.
    You already configured sender + app password above.
    """
    body = (
        f"Your verification code is: {code}\n\n"
        "Use this code in the application to complete verification."
    )

    msg = MIMEText(body)
    msg["From"] = SENDER_EMAIL
    msg["To"] = to_email
    msg["Subject"] = subject

    with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
        server.starttls()
        server.login(SENDER_EMAIL, SENDER_APP_PASSWORD)
        server.send_message(msg)
