# app.py
import json
import uuid
import os
import streamlit as st
import pandas as pd

from crypto_utils import (
    load_or_create_fernet_key, load_or_create_rsa_keys,
    encrypt_data, decrypt_data, hash_identity,
    sign_transaction
)

from db_utils import (
    get_conn, init_db, insert_victim, get_victims_by_status,
    update_victim_status, approve_fund, mark_fund_transferred,
    get_victim_by_did, get_victims_by_email,
    auth_user, get_user_email, update_user_password,
    add_block, get_blocks, get_user_row, victim_exists_by_govid_hash
)

from email_utils import (
    generate_otp, send_otp_email,
    SUBJECT_DID_RECOVERY, SUBJECT_ADMIN_RESET, SUBJECT_OFFICER_RESET
)

# ---------- Init ----------
init_db()
fernet = load_or_create_fernet_key()
private_key, public_key = load_or_create_rsa_keys()

st.set_page_config(
    page_title="Disaster Relief – Secure Fund Distribution",
    layout="wide",
    page_icon="💧"
)

# ---------- Global Header ----------
st.markdown(
    """
    <h1 style="text-align:center;"> Disaster Relief & Secure Fund Distribution System</h1>
    <p style="text-align:center; color:gray;">
        Secure victim registration • Region-based officer verification • Transparent blockchain fund tracking
    </p>
    <hr>
    """,
    unsafe_allow_html=True,
)
st.caption(f"Using database: `{os.path.abspath('disaster_fund.db')}`")

# ---------- Sidebar ----------
st.sidebar.header("Select Portal")
role = st.sidebar.radio(
    "",
    ["Victim", "Government Officer", "Admin", "View Blockchain"]
)

# Make sure session_state keys exist
for key in ["officer_logged_in", "admin_logged_in", "officer_region"]:
    if key not in st.session_state:
        st.session_state[key] = False if "logged_in" in key else ""


# ===================================================================
#  Victim  (Registration, Status, DID recovery)
# ===================================================================
if role == "Victim":
    tab1, tab2, tab3 = st.tabs([" Registration", " Check Status", " Recover DID"])

    # ----------------- Registration tab -----------------
    with tab1:
        st.subheader("Victim Registration Form")

        col_left, col_right = st.columns(2)

        with col_left:
            st.markdown("**Personal Details**")
            name = st.text_input("Full Name")
            phone = st.text_input("Phone Number")
            email = st.text_input("Email Address")
            govt_id = st.text_input("Government ID Number")

        with col_right:
            st.markdown("**Location Details**")
            address = st.text_area("Address")
            disaster_area = st.text_input("Disaster Area / Location")

        st.markdown("---")
        st.markdown("### 🏦 Bank Account Details")
        col_b1, col_b2 = st.columns(2)
        with col_b1:
            acc_holder = st.text_input("Account Holder Name")
            acc_number = st.text_input("Bank Account Number")
        with col_b2:
            ifsc = st.text_input("IFSC Code")
            upi_id = st.text_input("UPI ID (Optional)")

        requested_amount = st.number_input(
            "Requested Relief Amount (₹)", min_value=0.0, step=100.0
        )

        st.markdown("")
        if st.button(" Submit Registration", use_container_width=True):
            # Field validation
            if not all([name, phone, email, address, disaster_area,
                        govt_id, acc_holder, acc_number, ifsc]):
                st.error("Please fill all required fields.")
            else:
                # Generate hash for GovID + area (used as unique identity)
                gov_hash = hash_identity(govt_id, disaster_area)

                # Duplicate check
                if victim_exists_by_govid_hash(gov_hash):
                    st.error(" This Government ID is already registered for this disaster area.")
                else:
                    # Create DID & encrypted payload
                    did = "DID-" + uuid.uuid4().hex[:12]

                    payload = {
                        "name": name,
                        "phone": phone,
                        "email": email,
                        "address": address,
                        "disaster_area": disaster_area,
                        "account_holder": acc_holder,
                        "account_number": acc_number,
                        "ifsc": ifsc,
                        "upi_id": upi_id,
                    }
                    encrypted_payload = encrypt_data(fernet, json.dumps(payload))

                    insert_victim(
                        did, name, phone, email, address, disaster_area,
                        gov_hash, encrypted_payload, requested_amount
                    )

                    st.success(" Registration submitted successfully!")
                    st.info(f" Your DID (Save this safely): **{did}**")

    # ----------------- Check Status tab -----------------
    with tab2:
        st.subheader("Check Relief Status")

        col1, col2 = st.columns(2)
        with col1:
            did_input = st.text_input("Enter your DID")
        with col2:
            govt_id_check = st.text_input("Enter your Government ID")

        if st.button(" Check Status", use_container_width=True):
            row = get_victim_by_did(did_input)
            if not row:
                st.error(" Invalid DID! No record found.")
            else:
                area = row["disaster_area"]
                # Recompute hash and compare (ZKP-style check)
                if hash_identity(govt_id_check, area) != row["gov_id_hash"]:
                    st.error(" Identity verification failed!")
                else:
                    st.success(" Identity Verified")
                    st.write(f"**Status:** {row['status']}")
                    st.write(f"**Requested Amount:** ₹{row['requested_amount']}")
                    st.write(f"**Approved Amount:** ₹{row['approved_amount']}")
                    st.write(f"**Fund Status:** {row['fund_status']}")

    # ----------------- DID Recovery tab -----------------
    with tab3:
        st.subheader("Recover DID via Email")

        email_input = st.text_input("Registered Email Address", key="did_email")

        if st.button(" Send Verification Code", key="did_send_code"):
            victims = get_victims_by_email(email_input)
            if not victims:
                st.error("No victim found with this email.")
            else:
                code = generate_otp()
                st.session_state["did_recovery_email"] = email_input
                st.session_state["did_recovery_code"] = code

                # You configure email in email_utils.py
                send_otp_email(email_input, SUBJECT_DID_RECOVERY, code)
                st.success("Verification code has been sent to your email.")

        code_input = st.text_input(
            "Enter the 4-digit code received in email",
            key="did_code",
            max_chars=4
        )

        if st.button(" Verify & Show DID", key="did_verify"):
            stored_code = st.session_state.get("did_recovery_code")
            stored_email = st.session_state.get("did_recovery_email")

            if not stored_code or email_input != stored_email:
                st.error("Please request a code first.")
            elif code_input != stored_code:
                st.error("Invalid code.")
            else:
                victims = get_victims_by_email(stored_email)
                if not victims:
                    st.error("No victim found for this email.")
                else:
                    st.success("Verification successful ✔")
                    for v in victims:
                        st.write(f"Victim Name: **{v['name']}**, DID: **{v['did']}**")


# ===================================================================
#  Government Officer - Verification + Forgot Password
# ===================================================================
elif role == "Government Officer":
    st.subheader(" Government Officer Portal")

    username = st.text_input("Officer Username", value="officer1")
    password = st.text_input("Password", type="password")

    col1, col2 = st.columns(2)

    # ---------- Login ----------
    with col1:
        if st.button(" Login as Officer", use_container_width=True):
            user_row = get_user_row(username, "OFFICER", password)
            if user_row:
                st.session_state["officer_logged_in"] = True
                st.session_state["officer_username"] = user_row["username"]

                region = user_row["region"] if "region" in user_row.keys() else ""
                region = region or ""
                st.session_state["officer_region"] = region.strip()

                st.success(f"Logged in ✔ Region: **{st.session_state['officer_region'] or 'Not set'}**")
            else:
                st.error("Invalid Credentials!")

    # ---------- Forgot password ----------
    with col2:
        with st.expander("Forgot Password?"):
            fp_user = st.text_input("Officer Username", key="officer_fp_user")
            fp_email = st.text_input("Registered Email", key="officer_fp_email")

            if st.button("Send Code", key="officer_fp_send"):
                reg_email = get_user_email(fp_user)
                if not reg_email or reg_email != fp_email:
                    st.error("Username and email do not match any officer.")
                else:
                    code = generate_otp()
                    st.session_state["officer_reset_user"] = fp_user
                    st.session_state["officer_reset_code"] = code
                    send_otp_email(fp_email, SUBJECT_OFFICER_RESET, code)
                    st.success("Verification code sent to your email.")

            code = st.text_input("Enter 4-digit code", key="officer_fp_code", max_chars=4)
            new_pass = st.text_input("New Password", type="password",
                                     key="officer_fp_newpass")

            if st.button("Reset Password", key="officer_fp_reset"):
                if (code == st.session_state.get("officer_reset_code")
                        and fp_user == st.session_state.get("officer_reset_user")):
                    update_user_password(fp_user, new_pass)
                    st.success("Password updated successfully.")
                else:
                    st.error("Invalid code or username.")

    # ------------- Officer main area -------------
    if st.session_state.get("officer_logged_in"):
        st.markdown("---")
        st.subheader(" Pending Victims in Your Region")

        officer_region = (st.session_state.get("officer_region") or "").strip().lower()

        if not officer_region:
            st.warning("Your account does not have a region set. Ask admin to set one.")
        else:
            pending_all = get_victims_by_status("SUBMITTED")

            # Filter by region (safe for NULL values)
            pending = [
                v for v in pending_all
                if ((v["disaster_area"] or "").strip().lower() == officer_region)
            ]

            if not pending:
                st.info(f"No pending victims to verify for region: **{officer_region.title()}**")
            else:
                for row in pending:
                    with st.expander(f"Victim: {row['name']} (DID: {row['did']})"):
                        decrypted = json.loads(
                            decrypt_data(fernet, row["encrypted_payload"])
                        )

                        # Officer view – NO bank details
                        safe_view = {
                            "name": decrypted.get("name"),
                            "phone": decrypted.get("phone"),
                            "email": decrypted.get("email"),
                            "address": decrypted.get("address"),
                            "disaster_area": decrypted.get("disaster_area"),
                        }
                        st.json(safe_view)

                        action = st.radio(
                            "Verify Victim?",
                            ["Pending", "Verify", "Reject"],
                            key=f"verify_{row['id']}"
                        )

                        if st.button("Submit Decision", key=f"btn_{row['id']}"):
                            if action == "Verify":
                                update_victim_status(row["id"], "VERIFIED")
                                st.success("Victim Verified ✔")
                            elif action == "Reject":
                                update_victim_status(row["id"], "REJECTED")
                                st.warning("Victim Rejected ")
                            else:
                                st.info("No action taken.")


# ===================================================================
#  Admin Portal  (with DB viewer + forgot password)
# ===================================================================
elif role == "Admin":
    st.subheader(" Admin Portal")

    username = st.text_input("Admin Username", value="admin1")
    password = st.text_input("Password", type="password")

    col1, col2 = st.columns(2)

    # ---------- Admin login ----------
    with col1:
        if st.button(" Login as Admin", use_container_width=True):
            if auth_user(username, password, "ADMIN"):
                st.session_state["admin_logged_in"] = True
                st.success("Admin Logged in ✔")
            else:
                st.error("Invalid Credentials!")

    # ---------- Admin forgot password ----------
    with col2:
        with st.expander("Forgot Password?"):
            fp_user = st.text_input("Admin Username", key="admin_fp_user")
            fp_email = st.text_input("Registered Email", key="admin_fp_email")

            if st.button("Send Code", key="admin_fp_send"):
                reg_email = get_user_email(fp_user)
                if not reg_email or reg_email != fp_email:
                    st.error("Username and email do not match any admin.")
                else:
                    code = generate_otp()
                    st.session_state["admin_reset_user"] = fp_user
                    st.session_state["admin_reset_code"] = code
                    send_otp_email(fp_email, SUBJECT_ADMIN_RESET, code)
                    st.success("Verification code sent to your email.")

            code = st.text_input("Enter 4-digit code", key="admin_fp_code", max_chars=4)
            new_pass = st.text_input(
                "New Password",
                type="password",
                key="admin_fp_newpass"
            )

            if st.button("Reset Password", key="admin_fp_reset"):
                if (code == st.session_state.get("admin_reset_code")
                        and fp_user == st.session_state.get("admin_reset_user")):
                    update_user_password(fp_user, new_pass)
                    st.success("Password updated successfully.")
                else:
                    st.error("Invalid code or username.")

    # ---------- Admin main area ----------
    if st.session_state.get("admin_logged_in"):
        st.markdown("---")
        tabA, tabB, tabC = st.tabs(
            [" Approve Funds", " Mark Transfer", " Database Viewer"]
        )

        # -------- Fund Approval Tab --------
        with tabA:
            st.subheader("Approve Funds for Verified Victims")
            verified = get_victims_by_status("VERIFIED")

            if not verified:
                st.info("No verified victims waiting for approval.")
            else:
                for row in verified:
                    with st.expander(f"{row['name']} (DID: {row['did']})"):
                        st.write(f"**Requested Amount:** ₹{row['requested_amount']}")
                        amt = st.number_input(
                            "Approve Amount",
                            min_value=0.0,
                            value=float(row["requested_amount"]),
                            step=100.0,
                            key=f"approve_{row['id']}"
                        )

                        if st.button("Approve", key=f"appbtn_{row['id']}"):
                            approve_fund(row["id"], amt)
                            st.success("Fund Approved ✔")

        # -------- Fund Transfer Tab --------
        with tabB:
            st.subheader("Mark Funds as Transferred")
            approved = get_victims_by_status("VERIFIED")
            approved = [v for v in approved if v["fund_status"] == "APPROVED"]

            if not approved:
                st.info("No approved victims waiting for transfer.")
            else:
                for row in approved:
                    with st.expander(f"{row['name']} (DID: {row['did']})"):
                        st.write(f"Approved Amount: ₹{row['approved_amount']}")
                        if st.button("Mark Fund as Transferred", key=f"tx_{row['id']}"):
                            tx_data = json.dumps({
                                "victim_did": row["did"],
                                "amount": row["approved_amount"]
                            })
                            signature = sign_transaction(private_key, tx_data)

                            add_block(tx_data, signature)
                            mark_fund_transferred(row["id"])

                            st.success("Fund Transferred & Added to Blockchain ✔")

        # -------- Database Viewer Tab (Admin only, show ALL columns) --------
        with tabC:
            st.subheader("Admin Database Viewer – All Tables")

            conn = get_conn()

            # Victims table – all columns
            st.markdown("#### Victims Table (ALL Columns)")
            rows = conn.execute("SELECT * FROM victims").fetchall()
            victims_df = pd.DataFrame([dict(r) for r in rows])
            st.dataframe(victims_df, use_container_width=True)

            # Users table – all columns
            st.markdown("#### Users Table (ALL Columns)")
            rows = conn.execute("SELECT * FROM users").fetchall()
            users_df = pd.DataFrame([dict(r) for r in rows])
            st.dataframe(users_df, use_container_width=True)

            # Blockchain table – all columns
            st.markdown("#### Blockchain Ledger Table (ALL Columns)")
            rows = conn.execute("SELECT * FROM blocks").fetchall()
            blocks_df = pd.DataFrame([dict(r) for r in rows])
            st.dataframe(blocks_df, use_container_width=True)

            conn.close()


# ===================================================================
#  Blockchain Viewer (read-only)
# ===================================================================
elif role == "View Blockchain":
    st.subheader(" Public Blockchain Ledger (Read-only)")

    blocks = get_blocks()

    if not blocks:
        st.info("No Transactions Yet.")
    else:
        for block in blocks:
            with st.expander(f"Block #{block['id']}"):
                st.json({
                    "prev_hash": block["prev_hash"],
                    "tx_data": block["tx_data"],
                    "tx_hash": block["tx_hash"],
                    "signature": block["signature"],
                    "created_at": block["created_at"]
                })
